<?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $two): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="pay<?php echo e($two->id); ?>">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <img src="<?php echo e(asset('storage/assets/' . $two->foto)); ?>" width="300" alt="">
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\laravel\preset_undangan\resources\views/pay/modal.blade.php ENDPATH**/ ?>