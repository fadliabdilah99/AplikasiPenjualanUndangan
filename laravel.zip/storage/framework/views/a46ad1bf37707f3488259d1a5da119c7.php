

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('pay.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(session('success')): ?>
        <div id="toastsContainerTopRight" class="toasts-top-right fixed">
            <div class="toast bg-info fade show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header"><strong class="mr-auto">Info</strong><small>Important</small></div>
                <div class="toast-body"> <?php echo e(session('success')); ?></div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('noted')): ?>
        <div id="toastsContainerTopRight" class="toasts-top-right fixed">
            <div class="toast bg-warning fade show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header"><strong class="mr-auto">Info</strong><small>Important</small></div>
                <div class="toast-body"> <?php echo e(session('noted')); ?></div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
            <h5><i class="icon fas fa-ban"></i>Data Gagal Disimpan!</h5>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>




    <div class="container py-4">

        <table id="example1" class="datatables table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>Id Undangan</th>
                    <th>Pengantin</th>
                    <th>Bukti Pembayaran</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pay->undagan_id); ?></td>
                        <td><?php echo e($pay->pengantin_l); ?> & <?php echo e($pay->pengantin_p); ?></td>
                        <td> <button class="btn btn-warning" type="button" data-toggle="modal"
                                data-target="#pay<?php echo e($pay->id); ?>">Bukti Transfer</button></td>
                        <td>
                            <div class="row  justify-content-center" style="gap:10px;">
                                <form action="confirpay/<?php echo e($pay->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input hidden type="number" value="<?php echo e($pay->No); ?>" name="No">
                                    <input hidden type="number" value="<?php echo e($pay->undagan_id); ?>" name="undangan_id">
                                    <input hidden type="email" name="send" value="<?php echo e(Auth::user()->email); ?>">
                                    <input hidden type="email" name="to" value="<?php echo e($pay->email); ?>">
                                    <input hidden type="text" name="title" value="Notifikasi Pembayaran">
                                    <input hidden type="text" name="massage"
                                        value="Hallo Pelanggan Setia Kami, Kami Menginformasikan undangan dari pengantin <?php echo e($pay->pengantin_l); ?> & <?php echo e($pay->pengantin_p); ?> telah terkonfirmasi dan BERHASIL anda sekarang bisa mengakses undangan hingga batas wakti resepsi">
                                    <button type="submit" class="btn btn-success">Konfirmasi</button>
                                </form>
                                <form action="tolakpay/<?php echo e($pay->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input hidden type="email" name="send" value="<?php echo e(Auth::user()->email); ?>">
                                    <input hidden type="email" name="to" value="<?php echo e($pay->email); ?>">
                                    <input hidden type="text" name="title" value="Notifikasi Pembayaran">
                                    <input hidden type="text" name="massage"
                                        value="Hallo Pelanggan Setia Kami, Kami Menginformasikan undangan dari pengantin <?php echo e($pay->pengantin_l); ?> & <?php echo e($pay->pengantin_p); ?> telah terkonfirmasi dan Gagal Melakan Pembayaran karna alsan tertentu, mohon hubungi admin@admin.com untuk aduan penolakan">
                                    <button type="submit" class="btn btn-danger">tolak</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

            <tfoot>
                <tr>
                    <th>Id Undangan</th>
                    <th>Pengantin</th>
                    <th>Bukti Pembayaran</th>
                    <th>Aksi</th>
                </tr>
            </tfoot>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\preset_undangan\resources\views/pay/index.blade.php ENDPATH**/ ?>